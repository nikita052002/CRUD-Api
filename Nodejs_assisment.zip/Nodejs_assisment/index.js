var express = require('express');
var { v4: uuidv4 } = require('uuid');
var cluster = require('cluster');
var numCPUs = require('os').cpus().length;
var dotenv = require('dotenv');

dotenv.config();

var app = express();
app.use(express.json());


var users = [];

// Mode specific port configuration
var PORT = process.env.NODE_ENV === 'production' ? process.env.PROD_PORT : process.env.DEV_PORT || 3000;

// Function to validate UUID
function isValidUUID(uuid) {
  var uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
  return uuidRegex.test(uuid);
}

// Route to get all users
app.get('/api/users', (req, res) => {
  res.status(200).json(users);
});

// Route to get a user by ID
app.get('/api/users/:userId', (req, res) => {
  var userId = req.params.userId;

  if (!isValidUUID(userId)) {
    return res.status(400).json({ error: 'Invalid userId format' });
  }

  var user = users.find(u => u.id === userId);

  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  res.status(200).json(user);
});

// Route to create a new user
app.post('/api/users', (req, res) => {
  var { username, age, hobbies } = req.body;

  if (!username || !age || !hobbies) {
    return res.status(400).json({ error: 'Username, age, and hobbies are required fields' });
  }

  var newUser = { id: uuidv4(), username, age, hobbies };
  users.push(newUser);

  res.status(201).json(newUser);
});

// Route to update an existing user
app.put('/api/users/:userId', (req, res) => {
  var userId = req.params.userId;

  if (!isValidUUID(userId)) {
    return res.status(400).json({ error: 'Invalid userId format' });
  }

  var userIndex = users.findIndex(u => u.id === userId);

  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }

  var { username, age, hobbies } = req.body;

  if (!username || !age || !hobbies) {
    return res.status(400).json({ error: 'Username, age, and hobbies are required fields' });
  }

  var updatedUser = { id: userId, username, age, hobbies };
  users[userIndex] = updatedUser;

  res.status(200).json(updatedUser);
});

// Route to delete a user
app.delete('/api/users/:userId', (req, res) => {
  var userId = req.params.userId;

  if (!isValidUUID(userId)) {
    return res.status(400).json({ error: 'Invalid userId format' });
  }

  var userIndex = users.findIndex(u => u.id === userId);

  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }

  users.splice(userIndex, 1);

  res.status(204).send();
});

// Handling non-existing endpoints
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Handling errors on the server side
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal Server Error' });
});

// Running in cluster mode for production
if (process.env.NODE_ENV === 'production') {
  if (cluster.isMaster) {
    console.log(`Master ${process.pid} is running`);

    // Fork workers
    for (let i = 0; i < numCPUs; i++) {
      cluster.fork();
    }

    cluster.on('exit', (worker, code, signal) => {
      console.log(`Worker ${worker.process.pid} died`);
    });
  } else {
    // Worker
    app.listen(PORT + cluster.worker.id, () => {
      console.log(`Worker ${process.pid} is running on port ${PORT + cluster.worker.id}`);
    });
  }
} else {
  // Running in development mode
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}
